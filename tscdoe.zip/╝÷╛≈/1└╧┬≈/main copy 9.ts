// Pass.. 안전하지 않은 타입 '단언'..

import {info} from './info'

interface User{
  name:string
  age:number
}

// 선언
//const userA : User = { 
//  name: 'Neo' ,
//  age : 22
//} 

//만족 satisfies
const userA = { 
  info: info satisfies User,
  photo : null
} 

//단언
const userB = {

} as User

userB.name = 'Neo'
userB.age = 11

//만족
const userC = {} satisfies User

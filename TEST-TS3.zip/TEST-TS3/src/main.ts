import { mul } from "./mul"
// import data from "./data.json"

const add = (a: number, b: number) => {
    return a + b
}

console.log(add(1, 2))
console.log(mul(1, 2))
// console.log(data.includes(2))

const liEls = document.querySelectorAll('li')

Array.from(liEls).filter(el => console.log(el.textContent));


// export add// {} <= 코드 블럭

// export {
//     add
// }

//import / export 가 있으면 지역
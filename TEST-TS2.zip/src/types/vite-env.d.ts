///<reference types="vite/client"/>
// "///" 지시자 << TS에서만 사용

interface ImportMetaEnv{ // 기존 ImportMetaEnv와 병합
  readonly VITE_TODO_API_URL:string
  readonly VITE_TODO_APIKEY:string
  readonly VITE_TODO_USERNAME:string
}
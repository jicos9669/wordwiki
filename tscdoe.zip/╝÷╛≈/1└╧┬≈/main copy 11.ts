import {info} from './info'

interface User{
  name:string
  age:number
  email:string
}

// } as const 좁게 추론 
const user = {
  name : 'Neo',
  age : 22,
  email : "111"
} as const

user.name = 'Evan'
user.age = 23



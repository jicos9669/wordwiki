interface IUser {
  name : string
  getName() : string
}

class User {
  
  name
  
  constructor(name:string){
    //this.#name = name
    this.name = name
  }
  //#name //프라이빗 프로퍼티

  getName(){
    return this.name
  }

  getName2 = () =>{
    return this.name
  }
}

const a = new User("123")
const b = new User("1234")

console.log(a.getName());
console.log(a.getName2());


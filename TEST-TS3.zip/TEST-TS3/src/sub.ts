const sub =  (a:number, b:number) => {
    return a - b
}
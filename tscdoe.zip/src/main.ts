function add(x: number, y: number = 0): number {
  return x + y 
}
const sum = add(2)
console.log(sum)
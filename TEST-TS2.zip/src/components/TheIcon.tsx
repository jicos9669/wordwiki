import { twMerge } from 'tailwind-merge'

interface Props {
  children : React.ReactNode
  active? : boolean
  circle?: boolean
   className?:string
}

export default function TheIcon({ children, active, circle, ...rest }:Props & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...rest}
      className={twMerge(
        'box-border flex h-8 w-8 cursor-pointer items-center justify-center select-none',
        circle && 'rounded-full border border-gray-200',
        active && 'border border-(--color-highlight) bg-(--color-highlight)',
        rest.className
      )}>
      <span
        className={twMerge(
          'material-symbols-outlined',
          circle && 'opacity-0',
          active && 'text-white opacity-100'
        )}>
        {children}
      </span>
    </div>
  )
}

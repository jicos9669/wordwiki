// declare module 'lodash' {
//     interface Lodash {
//         upperCase(str:string):string
//     }
//     const _ : Lodash
//     export default _
// }


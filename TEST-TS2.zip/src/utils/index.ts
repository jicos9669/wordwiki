import dayjs from 'dayjs'

export function delay(ms = 1000) {
  return new Promise(resolve => setTimeout(resolve, ms))
}
export function formatDate(date : dayjs.ConfigType, format = 'YYYY년 M월 D일 H시 m분') {
  return dayjs(date).format(format)
}


// const d = dayjs()
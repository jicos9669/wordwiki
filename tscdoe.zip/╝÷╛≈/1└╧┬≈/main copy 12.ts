type TAdd = (a:number, b:number) => number

interface IAdd {
  (a:number, b:number):number //함수 패턴

}

//const add : TAdd = (a,b) => a+b

const add : IAdd = (a,b) => a+b


interface Person {
  name :string
}
interface Person {
  age :number
}



interface Devaloper extends Person{
  skill :  string
  lang : 'TS' | 'JS' | 'HTML'
}
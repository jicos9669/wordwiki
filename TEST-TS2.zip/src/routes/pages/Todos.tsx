import { useOutlet } from 'react-router'
import TodoCreator from '@/components/todos/TodoCreator'
import TodoList from '@/components/todos/TodoList'

export default function Todos() {
  const outlet = useOutlet()

  return (
    <main>
      <TodoCreator />
      <TodoList />
      {outlet}
    </main>
  )
}

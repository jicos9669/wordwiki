// import React from 'react'

export default function TheModal({ children, offModal = () => {} }:{children:React.ReactNode, offModal : ()=>void|boolean}) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center">
      <div
        className="absolute inset-0 h-full w-full cursor-pointer bg-black/70"
        onClick={offModal}></div>
      <div className="relative mx-5 max-h-[calc(100vh-40px)] w-full max-w-2xl overflow-auto rounded-md bg-white shadow-md">
        {children}
      </div>
    </div>
  )
}

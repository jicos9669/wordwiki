//const el : any =document.querySelector('.helloworld')

//el.focus()

const el : unknown =document.querySelector('.helloworld')
//타입 가드
if(el instanceof HTMLElement){
  el.focus()
}
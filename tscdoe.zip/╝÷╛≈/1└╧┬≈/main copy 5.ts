const user :{
  name : string
  getName:()=>string //getName:()=>void << 리턴데이터가 없을때 undefined와 동일
} = {
  name : 'Neo',
  getName(){
    console.log(this.name)
    return this.name
  }
}


user.getName();
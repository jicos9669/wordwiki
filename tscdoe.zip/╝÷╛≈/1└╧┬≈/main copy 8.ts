//타입 단언 from 개발자 to TS
//el!.focus() -> Non-null 연산자(타입스크립트)
//const el  = document.querySelector('input');
//el!.focus()

//;(el as HTMLInputElement).focus() AS 키워드
const el  = document.querySelector('input')
;(el as HTMLInputElement).focus()
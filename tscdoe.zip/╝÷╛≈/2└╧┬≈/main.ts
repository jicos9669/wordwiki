//함수 오버로드
function add<T extends string>(a: T, b: T): T // 함수 선언
function add<T extends number>(a: T, b: T): T // 함수 선언
function add(a: any, b: any): any { // 함수 구현
  return a + b
}

add('hello ', 'world~')
add(1, 2)
add('hello ', 2) // Error - No overload matches this call.
interface User {
  [key:string]:string
}
const key = "car"
const user : User = {
  name:'Neo',
  age : '22',
  [key] : 'BMW'

}

user.car
user[key]

//ArrayLike
interface FruitsLike {
  [key:number] : string
  length : number

}

const fruits = ['a','b','c']
const fruitsLike: FruitsLike = {
  0:'a',
  1:'b',
  2:'c',
  length:3
}

fruits[2]
fruitsLike[2]

fruits.includes("c")
Array.from(fruitsLike).includes("c");

const liEls = document.querySelectorAll('li')

const res = Array.from( liEls).filter(el => {
  return Number(el.textContent) < 20
})

console.log(res)

//Number('123') => 123
//Number.parseInt('123',10) => 123
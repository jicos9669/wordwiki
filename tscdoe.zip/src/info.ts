export const info = {
    name: 'Neo' ,
    age : 22

}
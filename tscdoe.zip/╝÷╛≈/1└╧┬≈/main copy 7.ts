//const add :(x :number,y : number)=>number = function(x,y) {
//  return x + y
//}
add(1,2)

const sub = function(x:number,y:number):number {
  return x - y
}

sub(1,2)

const mul = (x:number,y:number):number =>{
  return x * y
}

const mul2 = (x:number,y:number) =>{
  return x * y
}

function div (x:number,y:number):number {
  return x / y
}
export interface ResponseValue {
  Search: Movie[]
  totalResults: string
  Response: string
}

export interface Movie {
  Title: string
  Year: string
  imdbID: string
  Type: string
  Poster: string
}


async function fetchMovies(title:string): Promise<Movie[]>{
  //3초간 기다려라.
  await new Promise(resolve=>setTimeout(resolve,3000))
  const res = await fetch(`https://omdbapi.com?apiKey=7035c60c&s=${title}`)

  const data = await  res.json()

  console.log(data.Search)
  return data.Search
}

const movies = await fetchMovies("batman")
const movies2 = fetchMovies("batman")


function fetchMovies2(title:string): Promise<Movie[]>{
  return new Promise(resolve=>{
      fetch(`https://omdbapi.com?apiKey=7035c60c&s=${title}`)
      .then(res => res.json())
      .then(data=>resolve(data.Search))
  })

}

class Person {

}

const p:Person = new Person()


// 초기화된 변수 `num`
let num = 12

// 기본값이 설정된 매개 변수 `b`
function add(a: number, b = 2) {
  // 반환 값(`a + b`)이 있는 함수
  return a + b
}

add(2)
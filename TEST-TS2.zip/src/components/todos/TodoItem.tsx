import { Link } from 'react-router'
import { useUpdateTodo } from '@/hooks/todo'
import TheIcon from '@/components/TheIcon'
import type { Todo } from '@/hooks/todo'

export default function TodoItem({ todo }:{todo:Todo}) {
  const { mutate } = useUpdateTodo()

  function toggleDone() {
    mutate({
      ...todo,
      done: !todo.done
    })
  }

  return (
    <>
      <div className="relative flex h-[80px] items-center gap-5 border-b border-gray-200 bg-white px-6 select-none">
        <TheIcon
          circle
          active={todo.done}
          onClick={toggleDone}>
          check
        </TheIcon>
        <Link
          to={`/${todo.id}`}
          className="truncate hover:underline!">
          {todo.title}
        </Link>
        <div className="grow-1"></div>
        <Link to={`/${todo.id}`}>
          <TheIcon className="text-gray-200 duration-200 hover:text-gray-500">
            open_in_new
          </TheIcon>
        </Link>
      </div>
    </>
  )
}

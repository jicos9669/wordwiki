import { twMerge } from 'tailwind-merge'
import TheLoader from '@/components/TheLoader' // TheLoader 컴포넌트 경로는 그대로 유지됩니다.

interface Props {
  children : React.ReactNode
  active? : boolean
  success?: boolean
  danger?:boolean
  loading?:boolean
  className?:string
}

export default function TheButton({
  children,
  active,
  success,
  danger,
  loading,
  ...rest
}:Props & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={twMerge(
        'border-none',
        'flex min-w-18 cursor-pointer items-center justify-center border-l-1 border-solid border-gray-200 bg-white px-5 py-1.5 text-base font-bold text-gray-300 outline-none select-none',
        'hover:bg-gray-300 hover:text-white',
        active && 'text-(--color-highlight)',
        success &&
          'bg-(--color-highlight) text-white hover:bg-(--color-highlight)',
        danger && 'text-red-400 hover:bg-red-500',
        danger && loading && 'bg-red-500 text-white',
        rest.className
      )}>
      {loading ? (
        <TheLoader
          className={twMerge(
            success && 'border-white',
            danger && 'border-white'
          )}
        />
      ) : (
        children
      )}
    </button>
  )
}

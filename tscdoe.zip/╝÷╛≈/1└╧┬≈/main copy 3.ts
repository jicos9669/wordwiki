enum Week {
  Sun,
  Mon,
  Tue,
  Wed,
  Thu,
  Fri,
  Sat
}
enum MOBILE_OS {
  IOS, // 0
  ANDROID // 1
}


const w : Week = Week.Fri
///// Store /////
interface StoreObservers {
  [key: string]: SubscribeCallback[]
}
interface SubscribeCallback {
  (arg: unknown): void
}
  
export class Store<S> {
  public state = {} as S // 상태(데이터)
  private observers = {} as StoreObservers // 상태 변경 감지를 통해 실행할 콜백
  constructor(state: S) {
    for (const key in state) {
      // 각 상태에 대한 변경 감시(Setter) 설정!
      Object.defineProperty(this.state, key, {
        // Getter
        get: () => state[key],
        // Setter
        set: val => {
          state[key] = val
          if (Array.isArray(this.observers[key])) { // 호출할 콜백이 있는 경우!
            this.observers[key].forEach(observer => observer(val))
          }
        }
      })
    }
  }
  // 상태 변경 구독!
  subscribe(key: string, cb: SubscribeCallback) {
    Array.isArray(this.observers[key]) // 이미 등록된 콜백이 있는지 확인!
      ? this.observers[key].push(cb) // 있으면 새로운 콜백 밀어넣기!
      : this.observers[key] = [cb] // 없으면 콜백 배열로 할당!

    // 예시)
    // observers = {
    //   구독할상태이름: [실행할콜백1, 실행할콜백2]
    //   movies: [cb, cb, cb],
    //   message: [cb]
    // }
  }
}


const countStore = new Store<{
  count: number
  double: number
}>({
  count: 1,
  double: 2
})

const h1El = document.querySelector('h1')
function renderCount(count: number) {
  if (h1El) h1El.textContent = `${count}`
}
renderCount(countStore.state.count)

document.querySelector('button')?.addEventListener('click', () => {
  countStore.state.count += 1
})
countStore.subscribe('count', (val) => {
  console.log(val)
  renderCount(countStore.state.count)
})

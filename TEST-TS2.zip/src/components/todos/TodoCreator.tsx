import { useState, type KeyboardEvent } from 'react'
import { useCreateTodo, useFetchTodos } from '@/hooks/todo'
import TheLoader from '@/components/TheLoader'
import TheIcon from '@/components/TheIcon'

export default function TodoCreator() {
  const [title, setTitle] = useState('')
  const { mutateAsync, isPending } = useCreateTodo()
  const { isLoading } = useFetchTodos()

  function handleKeyDownEnter(event:React.KeyboardEvent<HTMLInputElement|HTMLTextAreaElement>) {
    if (event.nativeEvent.isComposing) return // 한글 중복 입력 방지!(macOS)
    if (event.key !== 'Enter') return // 엔터키 입력 확인!
    createTodo()
  }

  async function createTodo() {
    if (!title.trim()) return // 빈 문자 방지!
    if (isPending) return // 연속 입력 방지!
    setTitle('')
    await mutateAsync({ title })
  }

  return (
    <div className="relative mb-8 h-20 shadow-md">
      <div className="relative z-10 flex h-full w-20 items-center justify-center">
        {isPending || isLoading ? (
          <TheLoader/>
        ) : (
          <TheIcon
            circle
            active
            onClick={createTodo}>
            add
          </TheIcon>
        )}
      </div>
      <input
        value={title}
        className="absolute top-0 right-0 bottom-0 left-0 rounded-md border-0 bg-white p-0 pr-2.5 pl-20 outline-0 placeholder:text-gray-200"
        placeholder="새로운 할 일을 작성하세요~"
        onChange={e => setTitle(e.target.value)}
        onKeyDown={handleKeyDownEnter}
      />
    </div>
  )
}

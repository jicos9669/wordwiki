type MyType = `::${string}~`
let a : number = 123
let b : MyType = '::Hello~' //템플릿 리터럴, 보간

// -----------

const user :{
  name:string
  age:number
} = {
  name :'Neo',
  age:22
}

console.log(user.name.replace("N","n"))
//console.log(user.email.replace("N","n"))
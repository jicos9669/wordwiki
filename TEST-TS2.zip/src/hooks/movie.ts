import axios from 'axios'
// import {upperCase} from 'lodash/upperCase';
import _ from 'lodash';


// interface ResponseValue {
//     Response : 'True' |  'False',
   
// }
// interface ResponseValue {
//     Search :Movie[],
//     totalResults?:`${number}`
// }
// interface ResponseValue extends {Response:'False'} as ResponseValue {
//     Error?:string
// }


// export interface ResponseValue {
//     Response : 'True' |  'False',
//     // totalResults:string
//     Search?:Movie[],
//     totalResults?:`${number}`
//     Error?:string
// }

export type ResponseValue = {
    Response : 'True' ,
    Search:Movie[],
    totalResults:`${number}`
} | {
    Response :  'False',
    Error:string
}

// extends keyof

document.querySelectorAll('input')


export interface Movie{
    imdbID:string
    Title :string
} 

//named export , defult export
// export async function fetchMovies() : Promise<Movie[]> {
export async function fetchMovies(){
    const {data } = await axios<ResponseValue>('https://omdbapi.com?apiKey=7035c60c&s=batman')

    if(data.Response == 'True') {
        return data.Search.map(movie =>{
            return {
            ...movie, // 얕은 복사 ,  전개연산자
            Title:_.upperCase(movie.Title)
            }
        })
        // return data.Search

    } else{
        return []
    }
}
//원시형 : value 
//참조형 : Object
export const movies : Movie[] = []

export default {
    name :"Neo"
    ,age:22
}
abstract class Animal {
  abstract name: string
  age: number =1

  abstract bark():void


}

// class Animal {
//   constructor(public name: string, private age:number) {} //타입스크립트 문법
// }

class Dog extends Animal {
  constructor(public name: string, age : number) {
    super();

    this.age = age

  }
  getName(): string {
    return `Cat name is ${this.name}.`
  }
  static log(){
    console.log("!11");
  }
  bark(){
    
  }
}
const dog: Dog = new Dog("a",1)

console.log(Dog.log())
console.log(dog.getName())
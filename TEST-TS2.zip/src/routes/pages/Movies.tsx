import MovieList from "@/components/movies/MovieList";

export default function Movies(){
    return <>
    <MovieList></MovieList>
    </>
}
//const fruits : string[] = ['Apple', 'Banana', 'Cherry']
const fruits : Array<string> = ['Apple', 'Banana', 'Cherry']
//const numbers : number[] = [3, 5, 128, 11]
//const arr : (number | string | boolean)[] = [1, 'Hello', false]

let ex : unknown[] = [{},[],1,"d",false]

// <> 제네릭
// | 유니언
// & 인터섹션
// interface User<T>{

// }


function add<T extends string | number>(a: T, b: T): T {
  return a + b 
}

add(1, 2)
add("ab", "cd")

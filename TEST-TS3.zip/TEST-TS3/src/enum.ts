enum Colors {
    Red,
    Green =100,
    Blue,
}

const enum Week{  //const 가 있으면 최적화 하여 사용하지 않는것은 제외됨.
    Sun,
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sat,
}


console.log(Colors.Red)
console.log(Colors[1])

// console.log(Week[new Date().getDay()])
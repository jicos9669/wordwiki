// import { fetchMovies, movies} from '@hooks/movie' //named import
// import user from '@hooks/movie' //defult import

// import {type Movie, type ResponseValue} from '@/hooks/movie' //@는 vite 가 처리 해줌

import {fetchMovies} from '@/hooks/movie' //@는 vite 가 처리 해줌
import type {Movie} from '@/hooks/movie' //@는 vite 가 처리 해줌
import {useState, useEffect} from 'react'

export default function MovieList(){
    const [movies, setMovies] = useState<Movie[]>([])
    useEffect(()=>{
        init()        
    }, [])
    async function init(){
        const movies = await fetchMovies()
        setMovies(movies)
    }
    return <div>
        {movies.map(movie => {
            return <div key={movie.imdbID}>
                {movie.Title}
            </div>
        })}
    </div>
}
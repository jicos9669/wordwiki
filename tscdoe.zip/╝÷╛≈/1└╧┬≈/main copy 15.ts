

//T extends string | number <<  제약조건 
interface User<T extends string | number, T2> {
  name: string
  age: T
  email?: T2
}


const userA: User<number, string> = {
  name: 'Neo',
  age: 22,
}

const userB: User<string, string> = {
  name: 'Neo',
  age: "22",

}


const userC: User<string[]> = {
name: 'Neo',
  age: ['hello'],

} 


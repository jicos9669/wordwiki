const numbers : number[] = [1,2,3]

console.log(numbers.length)

numbers.push(4)

console.log(numbers.length)
console.log(numbers[7])
const tuple : [number,number,number] = [1,2,3]

tuple.push(4)

console.log(tuple.length)
console.log(tuple[4])

const users : [string,number][] = [
    ['Neo',22],
    ['Even',77],
    ['Lewis',99, false]
  ]
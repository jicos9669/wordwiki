import {info} from './info'

interface User{
  name:string
  age:number
  email:string
}


const user : Readonly<User> = {
  name : 'Neo',
  age : 22,
  email : "111"
}

user.age = 23
user.name = 'Evan'


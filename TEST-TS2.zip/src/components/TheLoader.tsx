import { twMerge } from 'tailwind-merge'

export default function TheLoader({ className }:{className?:string}) { // 객체분해 할당
  return (
    <div
      className={twMerge(
        'box-border h-8 w-8 animate-spin rounded-full border-3 border-(--color-highlight) border-t-transparent! select-none',
        className
      )}></div>
  )
}

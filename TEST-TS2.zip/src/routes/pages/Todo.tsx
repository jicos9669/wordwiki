import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router'
import { useFetchTodos, useUpdateTodo, useDeleteTodo } from '@/hooks/todo'
import TheIcon from '@/components/TheIcon'
import TheButton from '@/components/TheButton'
import TheModal from '@/components/TheModal'
import { formatDate } from '@/utils'

export default function Todo() {
  const navigate = useNavigate()
  const { todoId } = useParams()
  const { data: todos } = useFetchTodos()
  const { mutateAsync: mutateForUpdate, isPending: isPendingForUpdate } =
    useUpdateTodo()
  const { mutateAsync: mutateForDelete, isPending: isPendingForDelete } =
    useDeleteTodo()
  const [title, setTitle] = useState('')
  const [done, setDone] = useState(false)
  const currentTodo = todos?.find(todo => todo.id === todoId)

  useEffect(() => {
    if (currentTodo) {
      setTitle(currentTodo.title)
      setDone(currentTodo.done)
    }
  }, [currentTodo])

  async function updateTodo() {
    if (currentTodo) {
      await mutateForUpdate({
        ...currentTodo,
        title,
        done
      })
      offModal()
    }
  }
  async function deleteTodo() {
    if (currentTodo) {
      await mutateForDelete(currentTodo)
      offModal()
    }
  }
  function toggleDone() {
    setDone(done => !done)
  }
  function offModal() {
    navigate('/')
  }
  function onChange(event: React.ChangeEvent<HTMLTextAreaElement>) {
    setTitle(event.target.value)
  }

  return (
    <TheModal offModal={offModal}>
      <div className="relative h-15 border-b border-b-gray-200 bg-gray-100">
        <TheIcon
          circle
          className="absolute top-0 bottom-0 left-6 m-auto"
          active={done}
          onClick={toggleDone}>
          check
        </TheIcon>
        <div className="absolute right-0 flex h-full">
          <TheButton onClick={offModal}>취소</TheButton>
          <TheButton
            danger
            loading={isPendingForDelete}
            onClick={deleteTodo}>
            삭제
          </TheButton>
          <TheButton
            success
            loading={isPendingForUpdate}
            onClick={updateTodo}>
            저장
          </TheButton>
        </div>
      </div>
      <div className="flex gap-3.5 p-5 px-7 text-sm leading-none text-gray-400">
        <div>생성: {formatDate(currentTodo?.createdAt)}</div>
        {currentTodo?.createdAt !== currentTodo?.updatedAt && (
          <>
            <div>|</div>
            <div>수정: {formatDate(currentTodo?.updatedAt)}</div>
          </>
        )}
      </div>
      <textarea
        className="block h-37.5 w-full border-t border-none border-t-gray-200 bg-gray-100 p-3.5 px-5 font-[inherit] leading-normal outline-none"
        value={title || ''}
        onChange={onChange}
      />
    </TheModal>
  )
}

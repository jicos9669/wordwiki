
interface User {
  name : string
  age : number
  emails? : (string[]|string)
}

const users : User[] = [
  {name : 'Neo',
    age : 22,
    emails : ['neo@gmail.com']
  },
  {name : 'Even',
    age : 77,
    emails : 'test@gmail.com'
  },
  {name : 'Lewis',
    age : 77
  }
]
import { Fragment } from 'react'
import { useFetchTodos } from '@/hooks/todo'
import TodoFilters from '@/components/todos/TodoFilters'
import TodoItem from '@/components/todos/TodoItem'

export default function TodoList() {
  const { data: todos } = useFetchTodos()

  return (
    <div className="overflow-hidden rounded-md shadow-md">
      <TodoFilters />
      <div>
        {todos?.map(todo => (
          <Fragment key={todo.id}>
            <TodoItem todo={todo}></TodoItem>
          </Fragment>
        ))}
      </div>
    </div>
  )
}

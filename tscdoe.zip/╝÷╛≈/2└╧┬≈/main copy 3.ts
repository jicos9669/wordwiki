abstract class Animal {
  public name: string
  public age: number
  // #age: number
  protected isValid : boolean
  constructor(n: string, age : number) {
    this.name = n
    // this.#age = age
    this.age = age
    this.isValid = false
  }
}

// class Animal {
//   constructor(public name: string, private age:number) {} //타입스크립트 문법
// }

class Dog extends Animal {
  constructor(n: string, age : number) {
    // console.log(this.age)
    super(n,age)
  }
  getName(): string {
    return `Cat name is ${this.name}.`
  }
  static log(){
    console.log("!11");
  }
}
const dog: Dog = new Dog("a",1)

console.log(Dog.log())
console.log(dog.getName())
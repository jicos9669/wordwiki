import { createBrowserRouter, RouterProvider } from 'react-router'
import Todos from '@/routes/pages/Todos'
import Todo from '@/routes/pages/Todo'
import Movies from '@/routes/pages/Movies'

const router = createBrowserRouter([
  {
    path: '/',
    element: <Todos />,
    children: [
      {
        path: ':todoId',
        element: <Todo />
      }
    ]
  },
  {
    path: '/movies',
    element: <Movies ></Movies>,
    
  }
])

export default function Router() {
  return <RouterProvider router={router} />
}

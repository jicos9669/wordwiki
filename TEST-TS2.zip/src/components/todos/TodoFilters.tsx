import { useState, useEffect } from 'react'
import {
  useFetchTodos,
  useUpdateTodos,
  useTodoFilters,
  useDeleteTodos
} from '@/hooks/todo'
import TheIcon from '@/components/TheIcon'
import TheButton from '@/components/TheButton'

export default function TodoFilters() {
  const { data: todos } = useFetchTodos()
  const { mutate: mutateForUpdateTodos } = useUpdateTodos()
  const { mutate: mutateForDeleteTodos, isPending } = useDeleteTodos()
  const filterStatus = useTodoFilters(state => state.filterStatus)
  const filters = useTodoFilters(state => state.filters)
  const setFilterStatus = useTodoFilters(state => state.setFilterStatus)
  const [isAllChecked, setIsAllChecked] = useState(false)

  useEffect(() => {
    if (!todos) return
    setIsAllChecked(todos.every(todo => todo.done))
  }, [todos])

  function toggleAllCheckboxes() {
    const done = !isAllChecked
    setIsAllChecked(done)
    if (todos) {
      mutateForUpdateTodos(todos.map(todo => ({ ...todo, done })))
    }
  }
  function deleteAllDoneTodos() {
    if (todos) {
      mutateForDeleteTodos(todos)
    }
  }

  return (
    <div className="relative h-15 border-b border-b-gray-200 bg-gray-100">
      <div className="absolute right-0 flex h-full">
        {filters.map(filter => (
          <TheButton
            key={filter.value}
            active={filterStatus === filter.value}
            onClick={() => setFilterStatus(filter.value)}>
            {filter.text}
          </TheButton>
        ))}
        <TheButton
          danger
          loading={isPending}
          onClick={deleteAllDoneTodos}>
          완료 삭제
        </TheButton>
      </div>
      <TheIcon
        className="absolute top-0 bottom-0 left-6 m-auto"
        circle
        active={isAllChecked}
        onClick={toggleAllCheckboxes}>
        done_all
      </TheIcon>
    </div>
  )
}

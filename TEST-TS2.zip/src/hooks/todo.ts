import axios from 'axios'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { create } from 'zustand'
import { combine } from 'zustand/middleware'

// type ResponseValue = Todo[] // 할 일 목록

export interface Todo {
  id: string // 할 일 ID
  order: number // 할 일 순서
  title: string // 할 일 제목
  done: boolean // 할 일 완료 여부
  createdAt: string // 할 일 생성일
  updatedAt: string // 할 일 수정일
}

const request = axios.create({
  baseURL: import.meta.env.VITE_TODO_API_URL,
  headers: {
    'content-type': 'application/json',
    apikey: import.meta.env.VITE_TODO_APIKEY,
    username: import.meta.env.VITE_TODO_USERNAME
  }
})

export const useTodoFilters = create(
  combine({filterStatus: 'all',
    filters: [
      { text: '전체', value: 'all' },
      { text: '할 일', value: 'todo' },
      { text: '완료', value: 'done' }
    ]},
    set => ({
      setFilterStatus(status : string) {
        set({
          filterStatus: status
        })
      }
    })
  )
)

export const useFetchTodos = () => {
  const filterStatus = useTodoFilters(state => state.filterStatus)
  return useQuery<Todo[]>({
    queryKey: ['todos'],
    queryFn: async () => {
      const { data } = await request.get('/')
      return data
    },
    staleTime: 1000 * 60 * 5, // 5분
    select: todos => {
      return todos.filter(todo => {
        switch (filterStatus) {
          case 'todo':
            return !todo.done
          case 'done':
            return todo.done
          case 'all':
          default:
            return true
        }
      })
    }
  })
}
// 타이핑 => TS에서는 타입을 지정하는 행위를 뜻함.
export const useCreateTodo = () => {
  const queryClient = useQueryClient()
  return useMutation<Todo,Error,Partial<Todo>,{previousTodos?:Todo[]}>({
    mutationFn: async todo => {
      await new Promise(resolve => setTimeout(resolve, 1000))
      const { data } = await request.post('/', todo)
      return data
    },
    onMutate: async todo => {
      console.log('onMutate')
      // 낙관적 업데이트 전에 중복될 수 있는 쿼리를 모두 취소해 잠재적인 충돌 방지!
      await queryClient.cancelQueries({ queryKey: ['todos'] })
      // 캐시된 데이터(사용자 목록) 가져오기!
      const previousTodos = queryClient.getQueryData<Todo[]>(['todos'])
      // 낙관적 업데이트!
      if (previousTodos) {
        queryClient.setQueryData(
          ['todos'],
          [{ id: Math.random().toString(), ...todo }, ...previousTodos]
        )
      }
      // 각 콜백의 context로 전달할 데이터 반환!
      return { previousTodos }
    },
    onSuccess: () => {
      // 변이 성공 시 캐시 무효화로 목록 데이터 갱신!
      queryClient.invalidateQueries({ queryKey: ['todos'] })
    },
    onError: (_error, _payload, context) => {
      // 변이 실패 시, 낙관적 업데이트 결과를 이전 사용자 목록으로 되돌리기!
      if (context && context.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos)
      }
    }
  })
}

export const useUpdateTodo = () => {
  const queryClient = useQueryClient()
  return useMutation<Todo,Error,Partial<Todo>,{previousTodos?:Todo[]}>({
    mutationFn: async todo => {
      const { data } = await request.put(`/${todo.id}`, todo)
      return data
    },
    onMutate: async todo => {
      await queryClient.cancelQueries({ queryKey: ['todos'] })
      const previousTodos = queryClient.getQueryData<Todo[]>(['todos'])
      if (previousTodos) {
        // 수정할 할 일로 교체한, 새로운 할 일 목록 생성!
        const cloneTodos = previousTodos.map(pTodo => {
          return pTodo.id === todo.id ? todo : pTodo
        })
        queryClient.setQueryData(['todos'], cloneTodos)
      }
      return { previousTodos }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] })
    },
    onError: (_error, _payload, context) => {
      if (context && context.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos)
      }
    }
  })
}

export const useDeleteTodo = () => {
  const queryClient = useQueryClient()
  return useMutation<Todo,Error,Partial<Todo>,{previousTodos?:Todo[]}>({
    mutationFn: async todo => {
      const { data } = await request.delete(`/${todo.id}`)
      return data
    },
    onMutate: async todo => {
      await queryClient.cancelQueries({ queryKey: ['todos'] })
      const previousTodos = queryClient.getQueryData<Todo[]>(['todos'])
      if (previousTodos) {
        const cloneTodos = previousTodos.filter(pTodo => pTodo.id !== todo.id)
        queryClient.setQueryData(['todos'], cloneTodos)
      }
      return { previousTodos }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] })
    },
    onError: (_error, _payload, context) => {
      if (context && context.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos)
      }
    }
  })
}

export const useUpdateTodos = () => {
  const queryClient = useQueryClient()
  return useMutation<Todo[],Error,Todo[],{previousTodos?:Todo[]}>({
    mutationFn: async todos => {
      const { data } = await request.put('/updations', { todos })
      return data
    },
    onMutate: async todos => {
      await queryClient.cancelQueries({ queryKey: ['todos'] })
      const previousTodos = queryClient.getQueryData<Todo[]>(['todos'])
      if (previousTodos) {
        const cloneTodos = previousTodos.map(pTodo => {
          const todoToUpdate = todos.find(todo => todo.id === pTodo.id)
          return todoToUpdate || pTodo
        })
        queryClient.setQueryData(['todos'], cloneTodos)
      }
      return { previousTodos }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] })
    },
    onError: (_error, _payload, context) => {
      if (context && context.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos)
      }
    }
  })
}

export const useDeleteTodos = () => {
  const queryClient = useQueryClient()
  return useMutation<Todo[],Error,Todo[],{previousTodos?:Todo[]}>({
    mutationFn: async todos => {
      const todoIds =
        todos?.filter(todo => todo.done).map(todo => todo.id) || []
      if (!todoIds.length) throw new Error('삭제할 할 일 목록이 없습니다.')
      const { data } = await request.delete('/deletions', {
        data: { todoIds }
      })
      return data
    },
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ['todos'] })
      const previousTodos = queryClient.getQueryData<Todo[]>(['todos'])
      if (previousTodos) {
        const cloneTodos = previousTodos.filter(todo => !todo.done)
        queryClient.setQueryData(['todos'], cloneTodos)
      }
      return { previousTodos }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] })
    },
    onError: (_error, _payload, context) => {
      if (context && context.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos)
      }
    }
  })
}

/** JSDoc 문법
 * @param {number} a 
 * @param {number} b 
 * @returns {number}
 */
export const mul =  (a, b) => {
    return a * b
}
//const a : string & number = 123 //Naver

type MyType = string | number | boolean

const a : MyType = 123
const b : MyType = 'hello~'
const c : MyType = false


interface UserA {
  name: string
}

interface UserB{
  age : number
}

const user : UserA & UserB = {
  name : 'Neo'
  ,age : 22
}